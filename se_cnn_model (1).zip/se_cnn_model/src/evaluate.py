"""
Evaluation Module
Comprehensive model evaluation on test set
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, 
    roc_auc_score, confusion_matrix, classification_report,
    mean_absolute_error, mean_squared_error, r2_score, roc_curve
)
from . import config


class ModelEvaluator:
    def __init__(self, model):
        self.model = model
        self.predictions = None
        self.metrics = {}
        
    def prepare_inputs(self, X_num, X_cat):
        """Prepare inputs for prediction"""
        inputs = [X_num]
        for col in config.CATEGORICAL_FEATURES:
            if col in X_cat:
                inputs.append(X_cat[col])
        return inputs
    
    def predict(self, X_num, X_cat):
        """Make predictions"""
        inputs = self.prepare_inputs(X_num, X_cat)
        predictions = self.model.predict(inputs, verbose=0)
        
        # predictions[0] = classification probabilities
        # predictions[1] = regression values
        
        self.predictions = {
            'classification_probs': predictions[0].flatten(),
            'classification_labels': (predictions[0] > 0.5).astype(int).flatten(),
            'regression_values': predictions[1].flatten()
        }
        
        return self.predictions
    
    def evaluate_classification(self, y_true):
        """Evaluate classification performance"""
        y_pred = self.predictions['classification_labels']
        y_probs = self.predictions['classification_probs']
        
        metrics = {
            'accuracy': accuracy_score(y_true, y_pred),
            'precision': precision_score(y_true, y_pred, zero_division=0),
            'recall': recall_score(y_true, y_pred, zero_division=0),
            'f1_score': f1_score(y_true, y_pred, zero_division=0),
            'auc': roc_auc_score(y_true, y_probs)
        }
        
        self.metrics['classification'] = metrics
        return metrics
    
    def evaluate_regression(self, y_true):
        """Evaluate regression performance"""
        y_pred = self.predictions['regression_values']
        
        metrics = {
            'mae': mean_absolute_error(y_true, y_pred),
            'rmse': np.sqrt(mean_squared_error(y_true, y_pred)),
            'r2': r2_score(y_true, y_pred)
        }
        
        self.metrics['regression'] = metrics
        return metrics
    
    def print_evaluation_report(self):
        """Print comprehensive evaluation report"""
        print("\n" + "="*60)
        print("MODEL EVALUATION REPORT (SE-CNN)")
        print("="*60)
        
        if 'classification' in self.metrics:
            print("\n--- Classification Metrics ---")
            for metric, value in self.metrics['classification'].items():
                print(f"{metric.upper()}: {value:.4f}")
        
        if 'regression' in self.metrics:
            print("\n--- Regression Metrics ---")
            for metric, value in self.metrics['regression'].items():
                print(f"{metric.upper()}: {value:.4f}")
        
        print("="*60 + "\n")
    
    def plot_confusion_matrix(self, y_true, save_path=None):
        """Plot confusion matrix"""
        y_pred = self.predictions['classification_labels']
        cm = confusion_matrix(y_true, y_pred)
        
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=True,
                    xticklabels=['Low Performing', 'High Performing'],
                    yticklabels=['Low Performing', 'High Performing'])
        plt.title('Confusion Matrix - SE-CNN Model', fontsize=14, fontweight='bold')
        plt.ylabel('True Label')
        plt.xlabel('Predicted Label')
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"Confusion matrix saved to {save_path}")
        
        plt.show()
    
    def plot_roc_curve(self, y_true, save_path=None):
        """Plot ROC curve"""
        y_probs = self.predictions['classification_probs']
        fpr, tpr, _ = roc_curve(y_true, y_probs)
        auc = self.metrics['classification']['auc']
        
        plt.figure(figsize=(8, 6))
        plt.plot(fpr, tpr, linewidth=2, label=f'ROC Curve (AUC = {auc:.4f})')
        plt.plot([0, 1], [0, 1], 'k--', linewidth=1, label='Random Classifier')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('ROC Curve - SE-CNN Model', fontsize=14, fontweight='bold')
        plt.legend(loc='lower right')
        plt.grid(True, alpha=0.3)
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"ROC curve saved to {save_path}")
        
        plt.show()
    
    def plot_regression_results(self, y_true, save_path=None):
        """Plot regression predictions vs actuals"""
        y_pred = self.predictions['regression_values']
        
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))
        
        # Scatter plot
        axes[0].scatter(y_true, y_pred, alpha=0.5, s=30)
        axes[0].plot([y_true.min(), y_true.max()], 
                     [y_true.min(), y_true.max()], 
                     'r--', linewidth=2, label='Perfect Prediction')
        axes[0].set_xlabel('True LTV')
        axes[0].set_ylabel('Predicted LTV')
        axes[0].set_title('LTV: Predicted vs Actual')
        axes[0].legend()
        axes[0].grid(True, alpha=0.3)
        
        # Residual plot
        residuals = y_true - y_pred
        axes[1].scatter(y_pred, residuals, alpha=0.5, s=30)
        axes[1].axhline(y=0, color='r', linestyle='--', linewidth=2)
        axes[1].set_xlabel('Predicted LTV')
        axes[1].set_ylabel('Residuals')
        axes[1].set_title('Residual Plot')
        axes[1].grid(True, alpha=0.3)
        
        plt.suptitle(f'Regression Results - SE-CNN (MAE: {self.metrics["regression"]["mae"]:.4f}, R²: {self.metrics["regression"]["r2"]:.4f})',
                     fontsize=14, fontweight='bold')
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"Regression plots saved to {save_path}")
        
        plt.show()
    
    def compare_with_baselines(self, baseline_results):
        """Compare with baseline models"""
        print("\n" + "="*60)
        print("COMPARISON WITH BASELINE MODELS")
        print("="*60)
        
        comparison_df = pd.DataFrame(baseline_results)
        
        # Add SE-CNN results
        se_cnn_results = {
            'Model': 'SE-CNN (Proposed)',
            'Precision (%)': self.metrics['classification']['precision'] * 100,
            'Recall (%)': self.metrics['classification']['recall'] * 100,
            'Accuracy (%)': self.metrics['classification']['accuracy'] * 100,
            'AUC': self.metrics['classification']['auc']
        }
        comparison_df = pd.concat([comparison_df, pd.DataFrame([se_cnn_results])], ignore_index=True)
        
        print("\n", comparison_df.to_string(index=False))
        print("="*60 + "\n")
        
        # Plot comparison
        fig, axes = plt.subplots(1, 2, figsize=(14, 5))
        
        # Accuracy and Precision
        x = np.arange(len(comparison_df))
        width = 0.35
        
        axes[0].bar(x - width/2, comparison_df['Accuracy (%)'], width, label='Accuracy', alpha=0.8)
        axes[0].bar(x + width/2, comparison_df['Precision (%)'], width, label='Precision', alpha=0.8)
        axes[0].set_xlabel('Models')
        axes[0].set_ylabel('Score (%)')
        axes[0].set_title('Accuracy & Precision Comparison')
        axes[0].set_xticks(x)
        axes[0].set_xticklabels(comparison_df['Model'], rotation=15, ha='right')
        axes[0].legend()
        axes[0].grid(True, alpha=0.3, axis='y')
        
        # AUC
        axes[1].bar(comparison_df['Model'], comparison_df['AUC'], alpha=0.8, color='green')
        axes[1].set_xlabel('Models')
        axes[1].set_ylabel('AUC')
        axes[1].set_title('AUC Comparison')
        axes[1].set_xticklabels(comparison_df['Model'], rotation=15, ha='right')
        axes[1].grid(True, alpha=0.3, axis='y')
        axes[1].set_ylim([0.7, 1.0])
        
        plt.tight_layout()
        plt.savefig(config.RESULTS_DIR + '/baseline_comparison.png', dpi=300, bbox_inches='tight')
        plt.show()
        
        return comparison_df


def evaluate_model(model, test_data):
    """Main evaluation function"""
    X_test_num, X_test_cat, y_test_class, y_test_reg, test_df = test_data
    
    print("\n" + "="*60)
    print("EVALUATING SE-CNN MODEL ON TEST SET")
    print("="*60)
    print(f"Test samples: {len(y_test_class)}")
    print("="*60 + "\n")
    
    # Initialize evaluator
    evaluator = ModelEvaluator(model)
    
    # Make predictions
    print("Making predictions...")
    evaluator.predict(X_test_num, X_test_cat)
    
    # Evaluate classification
    print("Evaluating classification...")
    evaluator.evaluate_classification(y_test_class)
    
    # Evaluate regression
    print("Evaluating regression...")
    evaluator.evaluate_regression(y_test_reg)
    
    # Print report
    evaluator.print_evaluation_report()
    
    # Plot confusion matrix
    cm_path = config.RESULTS_DIR + '/confusion_matrix.png'
    evaluator.plot_confusion_matrix(y_test_class, save_path=cm_path)
    
    # Plot ROC curve
    roc_path = config.RESULTS_DIR + '/roc_curve.png'
    evaluator.plot_roc_curve(y_test_class, save_path=roc_path)
    
    # Plot regression results
    reg_path = config.RESULTS_DIR + '/regression_results.png'
    evaluator.plot_regression_results(y_test_reg, save_path=reg_path)
    
    # Compare with baselines
    baseline_results = [
        {'Model': 'Logistic Regression', 'Precision (%)': 71.2, 'Recall (%)': 68.9, 'Accuracy (%)': 73.5, 'AUC': 0.781},
        {'Model': 'XGBoost', 'Precision (%)': 75.9, 'Recall (%)': 73.8, 'Accuracy (%)': 77.4, 'AUC': 0.826},
        {'Model': 'WDL', 'Precision (%)': 79.8, 'Recall (%)': 78.4, 'Accuracy (%)': 81.6, 'AUC': 0.857},
    ]
    comparison_df = evaluator.compare_with_baselines(baseline_results)
    
    # Save comparison
    comparison_df.to_csv(config.RESULTS_DIR + '/model_comparison.csv', index=False)
    
    return evaluator, comparison_df

