"""
Utility Functions
Helper functions for the project
"""
import os
import json
import numpy as np
import pandas as pd
from datetime import datetime
from . import config


def set_seeds(seed=config.RANDOM_SEED):
    """Set random seeds for reproducibility"""
    np.random.seed(seed)
    import random
    random.seed(seed)
    
    try:
        import tensorflow as tf
        tf.random.set_seed(seed)
    except ImportError:
        pass
    
    print(f"Random seed set to: {seed}")


def create_project_structure():
    """Create necessary project directories"""
    directories = [
        config.DATA_DIR,
        config.MODELS_DIR,
        config.RESULTS_DIR,
        os.path.join(config.RESULTS_DIR, 'logs')
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
    
    print("Project directory structure created")


def save_experiment_config(additional_info=None):
    """Save experiment configuration"""
    exp_config = {
        'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        'model_type': 'SE-CNN (Squeeze-and-Excitation CNN)',
        'dataset_path': config.DATASET_PATH,
        'model_architecture': {
            'conv_filters_1': config.CONV_FILTERS_1,
            'conv_filters_2': config.CONV_FILTERS_2,
            'kernel_size': config.KERNEL_SIZE,
            'dense_units': config.DENSE_UNITS,
            'dropout_rate': config.DROPOUT_RATE,
            'embedding_dim': config.EMBEDDING_DIM,
            'se_reduction_ratio': config.SE_REDUCTION_RATIO
        },
        'training_params': {
            'batch_size': config.BATCH_SIZE,
            'epochs': config.EPOCHS,
            'learning_rate': config.LEARNING_RATE,
            'classification_loss_weight': config.CLASSIFICATION_LOSS_WEIGHT,
            'regression_loss_weight': config.REGRESSION_LOSS_WEIGHT
        },
        'optimization_params': {
            'total_budget': config.TOTAL_BUDGET,
            'min_budget_per_campaign': config.MIN_BUDGET_PER_CAMPAIGN,
            'max_budget_per_campaign': config.MAX_BUDGET_PER_CAMPAIGN
        }
    }
    
    if additional_info:
        exp_config['additional_info'] = additional_info
    
    config_path = os.path.join(config.RESULTS_DIR, 'experiment_config.json')
    with open(config_path, 'w') as f:
        json.dump(exp_config, f, indent=4)
    
    print(f"Experiment configuration saved to {config_path}")
    return exp_config


def generate_summary_report(train_metrics, eval_metrics, opt_results):
    """Generate a comprehensive summary report"""
    report_path = os.path.join(config.RESULTS_DIR, 'summary_report.txt')
    
    with open(report_path, 'w') as f:
        f.write("="*80 + "\n")
        f.write("SE-CNN-BASED MARKETING OPTIMIZATION - SUMMARY REPORT\n")
        f.write("="*80 + "\n\n")
        
        f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Model Type: SE-CNN (Squeeze-and-Excitation CNN)\n\n")
        
        f.write("-" * 80 + "\n")
        f.write("TRAINING RESULTS\n")
        f.write("-" * 80 + "\n")
        if train_metrics:
            for key, value in train_metrics.items():
                f.write(f"{key}: {value}\n")
        f.write("\n")
        
        f.write("-" * 80 + "\n")
        f.write("EVALUATION RESULTS\n")
        f.write("-" * 80 + "\n")
        if eval_metrics:
            f.write("\nClassification Metrics:\n")
            for key, value in eval_metrics['classification'].items():
                f.write(f"  {key}: {value:.4f}\n")
            
            f.write("\nRegression Metrics:\n")
            for key, value in eval_metrics['regression'].items():
                f.write(f"  {key}: {value:.4f}\n")
        f.write("\n")
        
        f.write("-" * 80 + "\n")
        f.write("OPTIMIZATION RESULTS\n")
        f.write("-" * 80 + "\n")
        if opt_results:
            f.write(f"Total Budget Allocated: ${opt_results['total_allocated']:,.2f}\n")
            f.write(f"Budget Utilization: {opt_results['budget_utilization']:.2f}%\n")
            f.write(f"Expected Total ROI: {opt_results['total_expected_roi']:,.2f}\n")
            f.write(f"Campaigns Funded: {opt_results['num_campaigns']}\n")
        
        f.write("\n" + "="*80 + "\n")
        f.write("END OF REPORT\n")
        f.write("="*80 + "\n")
    
    print(f"\nSummary report saved to {report_path}")
    
    # Also print to console
    with open(report_path, 'r') as f:
        print("\n" + f.read())


def check_data_quality(df):
    """Check data quality and print statistics"""
    print("\n" + "="*60)
    print("DATA QUALITY REPORT")
    print("="*60)
    
    print(f"\nTotal records: {len(df)}")
    print(f"Total features: {len(df.columns)}")
    
    print("\n--- Missing Values ---")
    missing = df.isnull().sum()
    missing_pct = (missing / len(df)) * 100
    missing_df = pd.DataFrame({'Count': missing, 'Percentage': missing_pct})
    missing_df = missing_df[missing_df['Count'] > 0].sort_values('Count', ascending=False)
    
    if len(missing_df) > 0:
        print(missing_df.to_string())
    else:
        print("No missing values found")
    
    print("\n--- Data Types ---")
    print(df.dtypes.value_counts())
    
    print("\n--- Numerical Features Statistics ---")
    numerical_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    print(df[numerical_cols].describe().to_string())
    
    print("\n" + "="*60 + "\n")


def print_banner(text):
    """Print a formatted banner"""
    width = 80
    print("\n" + "="*width)
    print(text.center(width))
    print("="*width + "\n")

