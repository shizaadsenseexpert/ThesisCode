"""
Data Preprocessing Module
Handles data cleaning, feature engineering, normalization, and splitting
"""
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
import joblib
from . import config


class DataPreprocessor:
    def __init__(self):
        self.scaler = StandardScaler()
        self.label_encoders = {}
        self.feature_dims = {}
        
    def load_data(self, filepath=config.DATASET_PATH):
        """Load dataset from CSV"""
        print(f"Loading data from {filepath}...")
        df = pd.read_csv(filepath)
        print(f"Initial dataset shape: {df.shape}")
        return df
    
    def clean_data(self, df):
        """Clean dataset: remove nulls, duplicates, invalid entries"""
        print("\n=== Data Cleaning ===")
        initial_rows = len(df)
        
        # Remove completely empty rows
        df = df.dropna(how='all')
        print(f"Removed {initial_rows - len(df)} empty rows")
        
        # Remove duplicate Ad_IDs
        initial_rows = len(df)
        df = df.drop_duplicates(subset=['Ad_ID'], keep='first')
        print(f"Removed {initial_rows - len(df)} duplicate Ad_IDs")
        
        # Remove rows with missing critical features
        critical_cols = ['CPC_USD', 'CTR', 'Conversion_Rate', 'Platform', 'Country']
        initial_rows = len(df)
        df = df.dropna(subset=critical_cols)
        print(f"Removed {initial_rows - len(df)} rows with missing critical data")
        
        # Remove outliers using IQR method for numerical features
        numerical_cols = config.NUMERICAL_FEATURES
        initial_rows = len(df)
        
        for col in numerical_cols:
            if col in df.columns:
                Q1 = df[col].quantile(0.25)
                Q3 = df[col].quantile(0.75)
                IQR = Q3 - Q1
                lower_bound = Q1 - 3 * IQR
                upper_bound = Q3 + 3 * IQR
                df = df[(df[col] >= lower_bound) & (df[col] <= upper_bound)]
        
        print(f"Removed {initial_rows - len(df)} outlier rows")
        print(f"Final cleaned dataset shape: {df.shape}\n")
        
        return df.reset_index(drop=True)
    
    def engineer_features(self, df):
        """Feature engineering: calculate derived features"""
        print("=== Feature Engineering ===")
        
        # Recalculate High_Performing_Label based on CTR and CPC
        ctr_threshold = df['CTR'].quantile(config.CTR_PERCENTILE / 100)
        cpc_threshold = df['CPC_USD'].quantile(config.CPC_PERCENTILE / 100)
        
        df['High_Performing_Label'] = (
            (df['CTR'] >= ctr_threshold) & 
            (df['CPC_USD'] <= cpc_threshold)
        ).astype(int)
        
        print(f"High-performing threshold: CTR >= {ctr_threshold:.4f}, CPC <= {cpc_threshold:.4f}")
        print(f"High-performing campaigns: {df['High_Performing_Label'].sum()} / {len(df)}")
        print(f"Class distribution: {df['High_Performing_Label'].value_counts().to_dict()}")
        
        # Ensure LTV_Proxy exists (recalculate if missing)
        if 'LTV_Proxy' not in df.columns or df['LTV_Proxy'].isna().any():
            df['LTV_Proxy'] = df['CTR'] * df['CPC_USD'] * df['Conversion_Rate']
            print("Recalculated LTV_Proxy")
        
        # Additional derived features (if not already present)
        if 'ROI' not in df.columns or df['ROI'].isna().any():
            df['ROI'] = (df['Conversion_Rate'] * 100) / (df['CPC_USD'] + 1e-6)
        
        if 'Cost_per_Lead' not in df.columns or df['Cost_per_Lead'].isna().any():
            conversions = df['Clicks'] * df['Conversion_Rate']
            df['Cost_per_Lead'] = df['Spend_USD'] / (conversions + 1e-6)
        
        print(f"Features engineered successfully\n")
        return df
    
    def encode_categorical(self, df, fit=True):
        """Encode categorical features"""
        print("=== Encoding Categorical Features ===")
        
        for col in config.CATEGORICAL_FEATURES:
            if col in df.columns:
                if fit:
                    self.label_encoders[col] = LabelEncoder()
                    df[col] = self.label_encoders[col].fit_transform(df[col].astype(str))
                    self.feature_dims[col] = len(self.label_encoders[col].classes_)
                    print(f"{col}: {self.feature_dims[col]} unique values")
                else:
                    # Handle unseen categories
                    le = self.label_encoders[col]
                    df[col] = df[col].astype(str).apply(
                        lambda x: le.transform([x])[0] if x in le.classes_ else -1
                    )
        
        print()
        return df
    
    def normalize_features(self, df, fit=True):
        """Normalize numerical features using StandardScaler"""
        print("=== Normalizing Numerical Features ===")
        
        numerical_cols = [col for col in config.NUMERICAL_FEATURES if col in df.columns]
        
        if fit:
            df[numerical_cols] = self.scaler.fit_transform(df[numerical_cols])
            print(f"Normalized {len(numerical_cols)} numerical features")
        else:
            df[numerical_cols] = self.scaler.transform(df[numerical_cols])
            print(f"Applied normalization to {len(numerical_cols)} features")
        
        print()
        return df
    
    def split_data(self, df):
        """Split data into train, validation, and test sets"""
        print("=== Splitting Data ===")
        
        # First split: train + val vs test
        train_val, test = train_test_split(
            df, 
            test_size=config.TEST_RATIO, 
            random_state=config.RANDOM_SEED,
            stratify=df[config.CLASSIFICATION_TARGET]
        )
        
        # Second split: train vs val
        val_ratio_adjusted = config.VAL_RATIO / (config.TRAIN_RATIO + config.VAL_RATIO)
        train, val = train_test_split(
            train_val,
            test_size=val_ratio_adjusted,
            random_state=config.RANDOM_SEED,
            stratify=train_val[config.CLASSIFICATION_TARGET]
        )
        
        print(f"Train set: {len(train)} samples ({len(train)/len(df)*100:.1f}%)")
        print(f"Validation set: {len(val)} samples ({len(val)/len(df)*100:.1f}%)")
        print(f"Test set: {len(test)} samples ({len(test)/len(df)*100:.1f}%)")
        print()
        
        return train, val, test
    
    def prepare_model_inputs(self, df):
        """Prepare X and y for model training"""
        # Numerical features
        X_numerical = df[config.NUMERICAL_FEATURES].values
        
        # Categorical features
        X_categorical = {}
        for col in config.CATEGORICAL_FEATURES:
            if col in df.columns:
                X_categorical[col] = df[col].values
        
        # Targets
        y_classification = df[config.CLASSIFICATION_TARGET].values
        y_regression = df[config.REGRESSION_TARGET].values
        
        return X_numerical, X_categorical, y_classification, y_regression
    
    def save_preprocessors(self):
        """Save scalers and encoders"""
        joblib.dump(self.scaler, config.SCALER_SAVE_PATH)
        joblib.dump(self.label_encoders, config.ENCODER_SAVE_PATH)
        joblib.dump(self.feature_dims, config.ENCODER_SAVE_PATH.replace('.pkl', '_dims.pkl'))
        print(f"Preprocessors saved to {config.MODELS_DIR}")
    
    def load_preprocessors(self):
        """Load saved scalers and encoders"""
        self.scaler = joblib.load(config.SCALER_SAVE_PATH)
        self.label_encoders = joblib.load(config.ENCODER_SAVE_PATH)
        self.feature_dims = joblib.load(config.ENCODER_SAVE_PATH.replace('.pkl', '_dims.pkl'))
        print(f"Preprocessors loaded from {config.MODELS_DIR}")
    
    def preprocess_pipeline(self, filepath=None, fit=True):
        """Complete preprocessing pipeline"""
        if filepath:
            df = self.load_data(filepath)
        else:
            df = self.load_data()
        
        df = self.clean_data(df)
        df = self.engineer_features(df)
        df = self.encode_categorical(df, fit=fit)
        df = self.normalize_features(df, fit=fit)
        
        if fit:
            self.save_preprocessors()
        
        return df


def preprocess_and_split():
    """Main function to preprocess data and create train/val/test splits"""
    preprocessor = DataPreprocessor()
    
    # Preprocess data
    df = preprocessor.preprocess_pipeline(fit=True)
    
    # Split data
    train_df, val_df, test_df = preprocessor.split_data(df)
    
    # Prepare model inputs
    X_train_num, X_train_cat, y_train_class, y_train_reg = preprocessor.prepare_model_inputs(train_df)
    X_val_num, X_val_cat, y_val_class, y_val_reg = preprocessor.prepare_model_inputs(val_df)
    X_test_num, X_test_cat, y_test_class, y_test_reg = preprocessor.prepare_model_inputs(test_df)
    
    data = {
        'train': (X_train_num, X_train_cat, y_train_class, y_train_reg, train_df),
        'val': (X_val_num, X_val_cat, y_val_class, y_val_reg, val_df),
        'test': (X_test_num, X_test_cat, y_test_class, y_test_reg, test_df),
        'preprocessor': preprocessor
    }
    
    return data

