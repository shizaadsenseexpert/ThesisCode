"""
Budget Optimization Module
Linear Programming-based budget allocation with fallback strategies
"""
import numpy as np
import pandas as pd
from pulp import LpProblem, LpMaximize, LpVariable, lpSum, LpStatus, value
import matplotlib.pyplot as plt
import seaborn as sns
from . import config


class BudgetOptimizer:
    def __init__(self, predictions, test_df, label_encoders=None):
        """
        Initialize budget optimizer
        
        Args:
            predictions: Model predictions (probabilities and LTV)
            test_df: Test dataframe with campaign details
            label_encoders: Dictionary of label encoders to decode categorical features
        """
        self.predictions = predictions
        self.test_df = test_df.copy()
        self.optimization_results = None
        self.label_encoders = label_encoders
        self.allocation_strategy = None
        
        # Decode categorical features to actual names
        if self.label_encoders:
            self._decode_categorical_features()
    
    def _decode_categorical_features(self):
        """Decode categorical features back to original names"""
        for col, encoder in self.label_encoders.items():
            if col in self.test_df.columns:
                # Handle potential -1 values (unseen categories)
                encoded_values = self.test_df[col].values
                decoded_values = []
                
                for val in encoded_values:
                    try:
                        if val >= 0 and val < len(encoder.classes_):
                            decoded_values.append(encoder.classes_[val])
                        else:
                            decoded_values.append('Unknown')
                    except:
                        decoded_values.append('Unknown')
                
                self.test_df[col] = decoded_values
        
        print(f"✓ Decoded categorical features to actual names")
        
    def prepare_optimization_data(self):
        """Prepare data for optimization"""
        # Add predictions to dataframe
        self.test_df['Predicted_Prob'] = self.predictions['classification_probs']
        self.test_df['Predicted_LTV'] = self.predictions['regression_values']
        
        # Calculate expected value: Probability × ROI × LTV
        self.test_df['Expected_Value'] = (
            self.test_df['Predicted_Prob'] * 
            self.test_df['ROI'] * 
            self.test_df['Predicted_LTV']
        )
        
        # Filter campaigns with positive expected value
        self.test_df = self.test_df[self.test_df['Expected_Value'] > 0].reset_index(drop=True)
        
        print(f"\nCampaigns eligible for optimization: {len(self.test_df)}")
        
    def solve_optimization_relaxed(self):
        """Solve with relaxed constraints (fallback method)"""
        print("\nAttempting optimization with relaxed constraints...")
        
        n_campaigns = len(self.test_df)
        
        # Create LP problem
        prob = LpProblem("Marketing_Budget_Optimization_Relaxed", LpMaximize)
        
        # Decision variables with relaxed bounds
        budgets = {
            i: LpVariable(f"budget_{i}", 
                         lowBound=0,  # Relaxed: allow zero budget
                         upBound=config.MAX_BUDGET_PER_CAMPAIGN)
            for i in range(n_campaigns)
        }
        
        # Objective: Maximize total expected value
        prob += lpSum([
            budgets[i] * self.test_df.loc[i, 'Expected_Value']
            for i in range(n_campaigns)
        ]), "Total_Expected_Value"
        
        # Only constraint: Total budget limit
        prob += lpSum([budgets[i] for i in range(n_campaigns)]) <= config.TOTAL_BUDGET, "Total_Budget_Constraint"
        
        # Solve
        prob.solve()
        
        if LpStatus[prob.status] == 'Optimal':
            print("✓ Relaxed optimization successful!")
            optimal_budgets = [value(budgets[i]) for i in range(n_campaigns)]
            self.test_df['Optimal_Budget'] = optimal_budgets
            
            # Filter out zero-budget campaigns
            self.test_df = self.test_df[self.test_df['Optimal_Budget'] > 0].reset_index(drop=True)
            self.allocation_strategy = 'flexible'
            return True
        
        return False
    
    def solve_optimization(self):
        """Solve linear programming problem for budget allocation"""
        print("\n" + "="*60)
        print("SOLVING BUDGET OPTIMIZATION PROBLEM")
        print("="*60)
        
        n_campaigns = len(self.test_df)
        
        # Strategy 1: Try full optimization with all constraints
        try:
            print("\nAttempt 1: Full optimization with platform constraints...")
            success = self._solve_full_optimization()
            if success:
                return self._finalize_results()
        except Exception as e:
            print(f"Full optimization failed: {str(e)}")
        
        # Strategy 2: Try relaxed optimization (no platform constraints)
        try:
            success = self.solve_optimization_relaxed()
            if success:
                return self._finalize_results()
        except Exception as e:
            print(f"Relaxed optimization failed: {str(e)}")
        
        print("\nNo feasible budget allocation found using constraint or flexible strategies.")
        self.allocation_strategy = None
        return None
    
    def _solve_full_optimization(self):
        """Try solving with full constraints"""
        n_campaigns = len(self.test_df)
        
        # Check if platform constraints are feasible
        platform_counts = self.test_df['Platform'].value_counts()
        print(f"\nPlatform distribution: {platform_counts.to_dict()}")
        
        # Create LP problem
        prob = LpProblem("Marketing_Budget_Optimization", LpMaximize)
        
        # Decision variables
        budgets = {
            i: LpVariable(f"budget_{i}", 
                         lowBound=config.MIN_BUDGET_PER_CAMPAIGN,
                         upBound=config.MAX_BUDGET_PER_CAMPAIGN)
            for i in range(n_campaigns)
        }
        
        # Objective
        prob += lpSum([
            budgets[i] * self.test_df.loc[i, 'Expected_Value']
            for i in range(n_campaigns)
        ]), "Total_Expected_Value"
        
        # Constraint 1: Total budget
        prob += lpSum([budgets[i] for i in range(n_campaigns)]) <= config.TOTAL_BUDGET, "Total_Budget_Constraint"
        
        # Constraint 2: Platform-wise budget (only if platform has campaigns)
        platforms = self.test_df['Platform'].unique()
        for platform in platforms:
            platform_indices = self.test_df[self.test_df['Platform'] == platform].index.tolist()
            
            if platform in config.PLATFORM_BUDGET_CONSTRAINTS and len(platform_indices) > 0:
                min_pct, max_pct = config.PLATFORM_BUDGET_CONSTRAINTS[platform]
                
                # Check if constraints are feasible for this platform
                min_required = min_pct * config.TOTAL_BUDGET
                max_allowed = max_pct * config.TOTAL_BUDGET
                
                # Min possible for this platform
                min_possible = len(platform_indices) * config.MIN_BUDGET_PER_CAMPAIGN
                # Max possible for this platform  
                max_possible = len(platform_indices) * config.MAX_BUDGET_PER_CAMPAIGN
                
                # Only add constraint if feasible
                if min_required <= max_possible and max_allowed >= min_possible:
                    prob += (
                        lpSum([budgets[i] for i in platform_indices]) >= 
                        min_required
                    ), f"{platform}_Min_Budget"
                    
                    prob += (
                        lpSum([budgets[i] for i in platform_indices]) <= 
                        max_allowed
                    ), f"{platform}_Max_Budget"
                else:
                    print(f"Skipping infeasible constraints for {platform}")
        
        # Solve
        prob.solve()
        
        if LpStatus[prob.status] == 'Optimal':
            print("✓ Full optimization successful!")
            optimal_budgets = [value(budgets[i]) for i in range(n_campaigns)]
            self.test_df['Optimal_Budget'] = optimal_budgets
            self.allocation_strategy = 'constraint'
            return True
        
        print(f"Full optimization status: {LpStatus[prob.status]}")
        return False
    
    def _finalize_results(self):
        """Finalize and calculate optimization results"""
        # Calculate metrics
        total_allocated = self.test_df['Optimal_Budget'].sum()
        total_expected_roi = (self.test_df['Optimal_Budget'] * self.test_df['Expected_Value']).sum()
        
        self.optimization_results = {
            'total_allocated': total_allocated,
            'total_expected_roi': total_expected_roi,
            'num_campaigns': len(self.test_df),
            'budget_utilization': (total_allocated / config.TOTAL_BUDGET) * 100
        }
        
        print(f"\nTotal Budget Allocated: ${total_allocated:,.2f}")
        print(f"Budget Utilization: {self.optimization_results['budget_utilization']:.2f}%")
        print(f"Expected Total ROI: {total_expected_roi:,.2f}")
        print(f"Campaigns Funded: {len(self.test_df)}")
        print("="*60 + "\n")
        
        return self.test_df
    
    def analyze_allocation(self):
        """Analyze budget allocation across dimensions"""
        print("\n" + "="*60)
        print("BUDGET ALLOCATION ANALYSIS")
        print("="*60)
        
        # Platform-wise allocation
        print("\n--- Platform-wise Budget Allocation ---")
        platform_allocation = self.test_df.groupby('Platform')['Optimal_Budget'].agg(['sum', 'count', 'mean'])
        platform_allocation['percentage'] = (platform_allocation['sum'] / self.optimization_results['total_allocated']) * 100
        platform_allocation.columns = ['Total Budget ($)', 'Campaigns', 'Avg Budget ($)', 'Percentage (%)']
        print(platform_allocation.to_string())
        
        # Country-wise allocation
        print("\n--- Country-wise Budget Allocation (Top 10) ---")
        country_allocation = self.test_df.groupby('Country')['Optimal_Budget'].agg(['sum', 'count', 'mean'])
        country_allocation['percentage'] = (country_allocation['sum'] / self.optimization_results['total_allocated']) * 100
        country_allocation.columns = ['Total Budget ($)', 'Campaigns', 'Avg Budget ($)', 'Percentage (%)']
        country_allocation = country_allocation.sort_values('Total Budget ($)', ascending=False).head(10)
        print(country_allocation.to_string())
        
        # Performance-based allocation
        print("\n--- High vs Low Performing Campaigns ---")
        perf_allocation = self.test_df.groupby('High_Performing_Label')['Optimal_Budget'].agg(['sum', 'count', 'mean'])
        perf_allocation['percentage'] = (perf_allocation['sum'] / self.optimization_results['total_allocated']) * 100
        perf_allocation.columns = ['Total Budget ($)', 'Campaigns', 'Avg Budget ($)', 'Percentage (%)']
        perf_allocation.index = ['Low Performing', 'High Performing']
        print(perf_allocation.to_string())
        
        print("="*60 + "\n")
        
        return platform_allocation, country_allocation, perf_allocation
    
    def plot_allocation(self, save_path=None):
        """Visualize budget allocation"""
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        
        # Platform allocation (pie chart)
        platform_data = self.test_df.groupby('Platform')['Optimal_Budget'].sum().sort_values(ascending=False)
        colors = sns.color_palette('Set3', len(platform_data))
        axes[0, 0].pie(platform_data.values, labels=platform_data.index, autopct='%1.1f%%',
                       startangle=90, colors=colors)
        axes[0, 0].set_title('Platform-wise Budget Distribution', fontweight='bold', fontsize=14)
        
        # Country allocation (top 10 bar chart)
        country_data = self.test_df.groupby('Country')['Optimal_Budget'].sum().sort_values(ascending=False).head(10)
        axes[0, 1].barh(range(len(country_data)), country_data.values, color='steelblue')
        axes[0, 1].set_yticks(range(len(country_data)))
        axes[0, 1].set_yticklabels(country_data.index, fontsize=10)
        axes[0, 1].set_xlabel('Budget ($)', fontsize=11)
        axes[0, 1].set_title('Top 10 Countries by Budget Allocation', fontweight='bold', fontsize=14)
        axes[0, 1].invert_yaxis()
        axes[0, 1].grid(axis='x', alpha=0.3)
        
        # Add value labels on bars
        for i, v in enumerate(country_data.values):
            axes[0, 1].text(v, i, f' ${v:,.0f}', va='center', fontsize=9)
        
        # Budget vs Expected Value (scatter)
        scatter = axes[1, 0].scatter(self.test_df['Optimal_Budget'], 
                          self.test_df['Expected_Value'],
                          alpha=0.6, s=50, c=self.test_df['Predicted_Prob'],
                          cmap='viridis', edgecolors='black', linewidth=0.5)
        axes[1, 0].set_xlabel('Optimal Budget ($)', fontsize=11)
        axes[1, 0].set_ylabel('Expected Value', fontsize=11)
        axes[1, 0].set_title('Budget Allocation vs Expected Value', fontweight='bold', fontsize=14)
        axes[1, 0].grid(True, alpha=0.3)
        cbar = plt.colorbar(scatter, ax=axes[1, 0])
        cbar.set_label('Success Probability', fontsize=10)
        
        # Budget distribution (histogram)
        axes[1, 1].hist(self.test_df['Optimal_Budget'], bins=30, color='coral', edgecolor='black', alpha=0.7)
        axes[1, 1].set_xlabel('Budget ($)', fontsize=11)
        axes[1, 1].set_ylabel('Frequency', fontsize=11)
        axes[1, 1].set_title('Budget Distribution Across Campaigns', fontweight='bold', fontsize=14)
        mean_budget = self.test_df['Optimal_Budget'].mean()
        axes[1, 1].axvline(mean_budget, color='red', 
                          linestyle='--', linewidth=2, label=f"Mean: ${mean_budget:,.0f}")
        axes[1, 1].legend(fontsize=10)
        axes[1, 1].grid(True, alpha=0.3, axis='y')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"Allocation plots saved to {save_path}")
        
        plt.show()
    
    def export_recommendations(self, filepath=None):
        """Export budget recommendations to CSV"""
        if filepath is None:
            filepath = config.RESULTS_DIR + '/budget_recommendations.csv'
        
        # Select relevant columns
        export_df = self.test_df[[
            'Ad_ID', 'Campaign_ID', 'Campaign_Name', 'Platform', 'Country',
            'CPC_USD', 'CTR', 'ROI', 'Predicted_Prob', 'Predicted_LTV',
            'Expected_Value', 'Optimal_Budget', 'High_Performing_Label'
        ]].sort_values('Optimal_Budget', ascending=False)
        
        export_df.to_csv(filepath, index=False)
        print(f"\nBudget recommendations exported to {filepath}")
        
        return export_df


def optimize_budget(predictions, test_df, label_encoders=None):
    """Main optimization function"""
    optimizer = BudgetOptimizer(predictions, test_df, label_encoders)
    
    # Prepare data
    optimizer.prepare_optimization_data()
    
    # Solve optimization
    result_df = optimizer.solve_optimization()
    
    if result_df is None or len(result_df) == 0:
        print("Optimization produced no results!")
        return None
    
    # Analyze allocation
    optimizer.analyze_allocation()
    
    # Visualize
    plot_path = config.RESULTS_DIR + '/budget_allocation.png'
    optimizer.plot_allocation(save_path=plot_path)
    
    # Export recommendations
    recommendations = optimizer.export_recommendations()
    
    return optimizer, recommendations