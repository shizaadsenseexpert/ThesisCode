"""
Configuration file for SE-CNN-based Marketing Optimization
"""
import os

# ===================== PATHS =====================
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DATA_DIR = os.path.join(BASE_DIR, 'data')
MODELS_DIR = os.path.join(BASE_DIR, 'se_cnn_model', 'models')
RESULTS_DIR = os.path.join(BASE_DIR, 'se_cnn_model', 'results')

# Create directories if they don't exist
os.makedirs(MODELS_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)

# Dataset path
DATASET_PATH = os.path.join(DATA_DIR, 'Dataset.csv')

# ===================== DATA PREPROCESSING =====================
# Features
NUMERICAL_FEATURES = [
    'CPC_USD', 'CTR', 'Conversion_Rate', 'Impressions', 
    'Clicks', 'Spend_USD', 'ROI', 'Click_Through_Lift', 
    'Cost_per_Lead', 'LTV_Proxy'
]

CATEGORICAL_FEATURES = [
    'Platform', 'Country', 'Campaign_ID'
]

# Target variables
CLASSIFICATION_TARGET = 'High_Performing_Label'
REGRESSION_TARGET = 'LTV_Proxy'

# Train/Val/Test split ratios
TRAIN_RATIO = 0.70
VAL_RATIO = 0.15
TEST_RATIO = 0.15

# High performing label calculation
CTR_PERCENTILE = 75  # Top 25% CTR
CPC_PERCENTILE = 25  # Bottom 25% CPC

# ===================== MODEL ARCHITECTURE =====================
# CNN parameters
CONV_FILTERS_1 = 32
CONV_FILTERS_2 = 64
KERNEL_SIZE = 3
POOL_SIZE = 2
DENSE_UNITS = 64
DROPOUT_RATE = 0.2

# SE (Squeeze-and-Excitation) block parameters
SE_REDUCTION_RATIO = 16  # Reduction ratio for SE blocks

# Embedding dimensions for categorical features
EMBEDDING_DIM = 8

# ===================== TRAINING PARAMETERS =====================
BATCH_SIZE = 32
EPOCHS = 20
LEARNING_RATE = 0.001
EARLY_STOPPING_PATIENCE = 15
LR_REDUCTION_PATIENCE = 10
LR_REDUCTION_FACTOR = 0.5
MIN_LEARNING_RATE = 1e-6
TRAIN_VERBOSE = 0  # Keras fit(verbose); set to 1 or 2 to show progress

# Loss weights for multi-task learning
CLASSIFICATION_LOSS_WEIGHT = 0.6
REGRESSION_LOSS_WEIGHT = 0.4

# ===================== OPTIMIZATION PARAMETERS =====================
# Budget constraints
TOTAL_BUDGET = 200000  # USD
MIN_BUDGET_PER_CAMPAIGN = 100  # Minimum spend per campaign
MAX_BUDGET_PER_CAMPAIGN = 50000  # Maximum spend per campaign

# Platform-wise budget allocation constraints (percentage of total)
# Note: These are flexible constraints - optimizer will use relaxed version if infeasible
PLATFORM_BUDGET_CONSTRAINTS = {
    'Google': (0.2, 0.6),    # Min 20%, Max 60% (wider range)
    'Meta': (0.15, 0.5),     # Min 15%, Max 50%
    'Twitter': (0.1, 0.5),   # Min 0%, Max 20%
    'LinkedIn': (0.1, 0.4),  # Min 0%, Max 20%
    'TikTok': (0.1, 0.2)     # Min 0%, Max 20%
}

# ===================== EVALUATION METRICS =====================
CLASSIFICATION_METRICS = ['accuracy', 'precision', 'recall', 'f1', 'auc']
REGRESSION_METRICS = ['mae', 'rmse', 'r2']

# ===================== RANDOM SEED =====================
RANDOM_SEED = 42

# ===================== MODEL SAVING =====================
MODEL_SAVE_PATH = os.path.join(MODELS_DIR, 'se_cnn_marketing_model.h5')
SCALER_SAVE_PATH = os.path.join(MODELS_DIR, 'scaler.pkl')
ENCODER_SAVE_PATH = os.path.join(MODELS_DIR, 'encoder.pkl')
HISTORY_SAVE_PATH = os.path.join(RESULTS_DIR, 'training_history.pkl')

