"""
SE-CNN Model Architecture for Marketing Optimization
Multi-task learning: Classification + Regression
With Squeeze-and-Excitation (SE) Channel Attention blocks
"""
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, Model
from . import config


def se_block(input_tensor, reduction_ratio=16, name_prefix=''):
    """
    Squeeze-and-Excitation (SE) block for channel attention
    
    Args:
        input_tensor: Input tensor (batch, timesteps, channels)
        reduction_ratio: Reduction ratio for the excitation network
        name_prefix: Prefix for layer names
    
    Returns:
        Output tensor with channel attention applied
    """
    # Get number of channels from tensor shape
    # After Conv1D layers, the channel dimension should be known
    channels = input_tensor.shape[-1]
    
    # Squeeze: Global Average Pooling
    se = layers.GlobalAveragePooling1D(name=f'{name_prefix}_se_global_pool')(input_tensor)
    
    # Excitation: Two FC layers with ReLU and Sigmoid
    se = layers.Dense(
        channels // reduction_ratio,
        activation='relu',
        name=f'{name_prefix}_se_dense1'
    )(se)
    se = layers.Dense(
        channels,
        activation='sigmoid',
        name=f'{name_prefix}_se_dense2'
    )(se)
    
    # Reshape to (batch, 1, channels) for broadcasting
    se = layers.Reshape((1, channels), name=f'{name_prefix}_se_reshape')(se)
    
    # Scale: Multiply input with attention weights
    output = layers.Multiply(name=f'{name_prefix}_se_scale')([input_tensor, se])
    
    return output


class MarketingSECNNModel:
    def __init__(self, feature_dims):
        """
        Initialize SE-CNN model
        
        Args:
            feature_dims: Dictionary with dimensions of categorical features
        """
        self.feature_dims = feature_dims
        self.model = None
        
    def build_model(self):
        """Build the SE-CNN architecture with multi-task heads"""
        
        # ========== INPUT LAYERS ==========
        # Numerical input
        numerical_input = layers.Input(
            shape=(len(config.NUMERICAL_FEATURES),), 
            name='numerical_input'
        )
        
        # Categorical inputs with embeddings
        categorical_inputs = {}
        categorical_embeddings = []
        
        for col in config.CATEGORICAL_FEATURES:
            if col in self.feature_dims:
                cat_input = layers.Input(shape=(1,), name=f'{col}_input', dtype='int32')
                categorical_inputs[col] = cat_input
                
                # Embedding layer
                embedding = layers.Embedding(
                    input_dim=self.feature_dims[col] + 1,  # +1 for unknown
                    output_dim=config.EMBEDDING_DIM,
                    name=f'{col}_embedding'
                )(cat_input)
                embedding = layers.Flatten()(embedding)
                categorical_embeddings.append(embedding)
        
        # Concatenate all features
        if categorical_embeddings:
            concatenated = layers.Concatenate()(
                [numerical_input] + categorical_embeddings
            )
        else:
            concatenated = numerical_input
        
        # Reshape for 1D CNN (add channel dimension)
        reshaped = layers.Reshape((-1, 1))(concatenated)
        
        # ========== CNN LAYERS WITH SE BLOCKS ==========
        # First Conv Block with SE
        conv1 = layers.Conv1D(
            filters=config.CONV_FILTERS_1,
            kernel_size=config.KERNEL_SIZE,
            activation='relu',
            padding='same',
            name='conv1d_1'
        )(reshaped)
        conv1 = layers.BatchNormalization(name='bn1')(conv1)
        
        # Apply SE block after first conv
        conv1 = se_block(conv1, reduction_ratio=config.SE_REDUCTION_RATIO, name_prefix='se1')
        
        conv1 = layers.MaxPooling1D(pool_size=config.POOL_SIZE, padding='same', name='pool1')(conv1)
        conv1 = layers.Dropout(config.DROPOUT_RATE, name='dropout1')(conv1)
        
        # Second Conv Block with SE
        conv2 = layers.Conv1D(
            filters=config.CONV_FILTERS_2,
            kernel_size=config.KERNEL_SIZE,
            activation='relu',
            padding='same',
            name='conv1d_2'
        )(conv1)
        conv2 = layers.BatchNormalization(name='bn2')(conv2)
        
        # Apply SE block after second conv
        conv2 = se_block(conv2, reduction_ratio=config.SE_REDUCTION_RATIO, name_prefix='se2')
        
        conv2 = layers.GlobalMaxPooling1D(name='global_pool')(conv2)
        
        # Dense layer
        dense = layers.Dense(
            config.DENSE_UNITS, 
            activation='relu',
            name='dense_shared'
        )(conv2)
        dense = layers.Dropout(config.DROPOUT_RATE, name='dropout_shared')(dense)
        
        # ========== MULTI-TASK HEADS ==========
        # Classification Head (High-performing prediction)
        classification_head = layers.Dense(
            32, 
            activation='relu',
            name='classification_dense'
        )(dense)
        classification_output = layers.Dense(
            1, 
            activation='sigmoid',
            name='classification_output'
        )(classification_head)
        
        # Regression Head (LTV estimation)
        regression_head = layers.Dense(
            32, 
            activation='relu',
            name='regression_dense'
        )(dense)
        regression_output = layers.Dense(
            1, 
            activation='linear',
            name='regression_output'
        )(regression_head)
        
        # ========== CREATE MODEL ==========
        inputs = [numerical_input] + list(categorical_inputs.values())
        outputs = [classification_output, regression_output]
        
        self.model = Model(inputs=inputs, outputs=outputs, name='Marketing_SE_CNN')
        
        return self.model
    
    def compile_model(self):
        """Compile model with loss functions and optimizer"""
        
        # Multi-task losses
        losses = {
            'classification_output': 'binary_crossentropy',
            'regression_output': 'mse'
        }
        
        # Loss weights
        loss_weights = {
            'classification_output': config.CLASSIFICATION_LOSS_WEIGHT,
            'regression_output': config.REGRESSION_LOSS_WEIGHT
        }
        
        # Metrics
        metrics = {
            'classification_output': [
                'accuracy',
                keras.metrics.Precision(name='precision'),
                keras.metrics.Recall(name='recall'),
                keras.metrics.AUC(name='auc')
            ],
            'regression_output': [
                'mae',
                keras.metrics.RootMeanSquaredError(name='rmse')
            ]
        }
        
        # Optimizer
        optimizer = keras.optimizers.Adam(learning_rate=config.LEARNING_RATE)
        
        self.model.compile(
            optimizer=optimizer,
            loss=losses,
            loss_weights=loss_weights,
            metrics=metrics
        )
        
        print("\n=== Model Compiled ===")
        print(f"Classification loss weight: {config.CLASSIFICATION_LOSS_WEIGHT}")
        print(f"Regression loss weight: {config.REGRESSION_LOSS_WEIGHT}")
        print(f"Learning rate: {config.LEARNING_RATE}")
        print(f"SE Reduction Ratio: {config.SE_REDUCTION_RATIO}\n")
        
        return self.model
    
    def summary(self):
        """Print model summary"""
        if self.model:
            self.model.summary()
        else:
            print("Model not built yet. Call build_model() first.")
    
    def save_model(self, filepath=config.MODEL_SAVE_PATH):
        """Save trained model"""
        if self.model:
            self.model.save(filepath)
            print(f"\nModel saved to {filepath}")
        else:
            print("No model to save. Train the model first.")
    
    def load_model(self, filepath=config.MODEL_SAVE_PATH):
        """Load saved model"""
        self.model = keras.models.load_model(filepath)
        print(f"\nModel loaded from {filepath}")
        return self.model


def create_model(feature_dims):
    """Helper function to create and compile model"""
    model_builder = MarketingSECNNModel(feature_dims)
    model = model_builder.build_model()
    model = model_builder.compile_model()
    
    print("\n=== Model Architecture ===")
    model_builder.summary()
    
    return model_builder

