"""
Training Module
Handles model training with callbacks and monitoring
"""
import numpy as np
import tensorflow as tf
from tensorflow import keras
import matplotlib.pyplot as plt
import joblib
from . import config


class ModelTrainer:
    def __init__(self, model):
        self.model = model
        self.history = None
        
    def prepare_inputs(self, X_num, X_cat):
        """Prepare inputs for model"""
        inputs = [X_num]
        for col in config.CATEGORICAL_FEATURES:
            if col in X_cat:
                inputs.append(X_cat[col])
        return inputs
    
    def setup_callbacks(self):
        """Setup training callbacks"""
        callbacks = []
        
        # Early Stopping
        early_stop = keras.callbacks.EarlyStopping(
            monitor='val_loss',
            patience=config.EARLY_STOPPING_PATIENCE,
            restore_best_weights=True,
            verbose=1
        )
        callbacks.append(early_stop)
        
        # Learning Rate Reduction
        lr_reduction = keras.callbacks.ReduceLROnPlateau(
            monitor='val_loss',
            patience=config.LR_REDUCTION_PATIENCE,
            factor=config.LR_REDUCTION_FACTOR,
            min_lr=config.MIN_LEARNING_RATE,
            verbose=1
        )
        callbacks.append(lr_reduction)
        
        # Model Checkpoint
        checkpoint = keras.callbacks.ModelCheckpoint(
            filepath=config.MODEL_SAVE_PATH,
            monitor='val_loss',
            save_best_only=True,
            verbose=1
        )
        callbacks.append(checkpoint)
        
        # TensorBoard
        tensorboard = keras.callbacks.TensorBoard(
            log_dir=config.RESULTS_DIR + '/logs',
            histogram_freq=1
        )
        callbacks.append(tensorboard)
        
        return callbacks
    
    def train(self, train_data, val_data):
        """
        Train the model
        
        Args:
            train_data: Tuple of (X_num, X_cat, y_class, y_reg)
            val_data: Tuple of (X_num, X_cat, y_class, y_reg)
        """
        X_train_num, X_train_cat, y_train_class, y_train_reg = train_data
        X_val_num, X_val_cat, y_val_class, y_val_reg = val_data
        
        # Prepare inputs
        train_inputs = self.prepare_inputs(X_train_num, X_train_cat)
        val_inputs = self.prepare_inputs(X_val_num, X_val_cat)
        
        # Prepare outputs
        train_outputs = {
            'classification_output': y_train_class,
            'regression_output': y_train_reg
        }
        val_outputs = {
            'classification_output': y_val_class,
            'regression_output': y_val_reg
        }
        
        # Setup callbacks
        callbacks = self.setup_callbacks()
        
        print("\n" + "="*60)
        print("STARTING MODEL TRAINING")
        print("="*60)
        print(f"Training samples: {len(y_train_class)}")
        print(f"Validation samples: {len(y_val_class)}")
        print(f"Batch size: {config.BATCH_SIZE}")
        print(f"Max epochs: {config.EPOCHS}")
        print("="*60 + "\n")
        
        # Train model
        self.history = self.model.fit(
            train_inputs,
            train_outputs,
            validation_data=(val_inputs, val_outputs),
            batch_size=config.BATCH_SIZE,
            epochs=config.EPOCHS,
            callbacks=callbacks,
            verbose=config.TRAIN_VERBOSE
        )
        
        print("\n" + "="*60)
        print("TRAINING COMPLETED")
        print("="*60 + "\n")
        
        # Save training history
        joblib.dump(self.history.history, config.HISTORY_SAVE_PATH)
        print(f"Training history saved to {config.HISTORY_SAVE_PATH}")
        
        return self.history
    
    def plot_training_history(self, save_path=None):
        """Plot training history"""
        if not self.history:
            print("No training history available")
            return
        
        history = self.history.history
        
        fig, axes = plt.subplots(2, 3, figsize=(18, 10))
        fig.suptitle('Training History - SE-CNN Model', fontsize=16, fontweight='bold')
        
        # Total Loss
        axes[0, 0].plot(history['loss'], label='Train Loss', linewidth=2)
        axes[0, 0].plot(history['val_loss'], label='Val Loss', linewidth=2)
        axes[0, 0].set_title('Total Loss')
        axes[0, 0].set_xlabel('Epoch')
        axes[0, 0].set_ylabel('Loss')
        axes[0, 0].legend()
        axes[0, 0].grid(True, alpha=0.3)
        
        # Classification Loss
        axes[0, 1].plot(history['classification_output_loss'], label='Train', linewidth=2)
        axes[0, 1].plot(history['val_classification_output_loss'], label='Val', linewidth=2)
        axes[0, 1].set_title('Classification Loss')
        axes[0, 1].set_xlabel('Epoch')
        axes[0, 1].set_ylabel('Loss')
        axes[0, 1].legend()
        axes[0, 1].grid(True, alpha=0.3)
        
        # Regression Loss
        axes[0, 2].plot(history['regression_output_loss'], label='Train', linewidth=2)
        axes[0, 2].plot(history['val_regression_output_loss'], label='Val', linewidth=2)
        axes[0, 2].set_title('Regression Loss (MSE)')
        axes[0, 2].set_xlabel('Epoch')
        axes[0, 2].set_ylabel('Loss')
        axes[0, 2].legend()
        axes[0, 2].grid(True, alpha=0.3)
        
        # Classification Accuracy
        axes[1, 0].plot(history['classification_output_accuracy'], label='Train', linewidth=2)
        axes[1, 0].plot(history['val_classification_output_accuracy'], label='Val', linewidth=2)
        axes[1, 0].set_title('Classification Accuracy')
        axes[1, 0].set_xlabel('Epoch')
        axes[1, 0].set_ylabel('Accuracy')
        axes[1, 0].legend()
        axes[1, 0].grid(True, alpha=0.3)
        
        # Classification AUC
        axes[1, 1].plot(history['classification_output_auc'], label='Train', linewidth=2)
        axes[1, 1].plot(history['val_classification_output_auc'], label='Val', linewidth=2)
        axes[1, 1].set_title('Classification AUC')
        axes[1, 1].set_xlabel('Epoch')
        axes[1, 1].set_ylabel('AUC')
        axes[1, 1].legend()
        axes[1, 1].grid(True, alpha=0.3)
        
        # Regression MAE
        axes[1, 2].plot(history['regression_output_mae'], label='Train', linewidth=2)
        axes[1, 2].plot(history['val_regression_output_mae'], label='Val', linewidth=2)
        axes[1, 2].set_title('Regression MAE')
        axes[1, 2].set_xlabel('Epoch')
        axes[1, 2].set_ylabel('MAE')
        axes[1, 2].legend()
        axes[1, 2].grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
            print(f"Training plots saved to {save_path}")
        
        plt.show()
        
    def get_final_metrics(self):
        """Get final training metrics"""
        if not self.history:
            print("No training history available")
            return None
        
        history = self.history.history
        
        metrics = {
            'final_train_loss': history['loss'][-1],
            'final_val_loss': history['val_loss'][-1],
            'final_train_accuracy': history['classification_output_accuracy'][-1],
            'final_val_accuracy': history['val_classification_output_accuracy'][-1],
            'final_train_auc': history['classification_output_auc'][-1],
            'final_val_auc': history['val_classification_output_auc'][-1],
            'final_train_mae': history['regression_output_mae'][-1],
            'final_val_mae': history['val_regression_output_mae'][-1],
            'best_epoch': np.argmin(history['val_loss']) + 1,
            'total_epochs': len(history['loss'])
        }
        
        print("\n" + "="*60)
        print("FINAL TRAINING METRICS")
        print("="*60)
        for key, value in metrics.items():
            if 'epoch' in key:
                print(f"{key}: {value}")
            else:
                print(f"{key}: {value:.4f}")
        print("="*60 + "\n")
        
        return metrics


def train_model(model, train_data, val_data):
    """Helper function to train model"""
    trainer = ModelTrainer(model)
    history = trainer.train(train_data, val_data)
    
    # Plot training history
    plot_path = config.RESULTS_DIR + '/training_history.png'
    trainer.plot_training_history(save_path=plot_path)
    
    # Get final metrics
    metrics = trainer.get_final_metrics()
    
    return trainer, metrics

