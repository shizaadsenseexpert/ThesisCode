"""
SE-CNN Marketing Optimization Package
Squeeze-and-Excitation CNN for Marketing Optimization
"""

import warnings

warnings.filterwarnings("ignore")

__version__ = "1.0.0"
__author__ = "Shiza Zahid"

from . import config
from .data_preprocessing import DataPreprocessor, preprocess_and_split
from .model import MarketingSECNNModel, create_model
from .train import ModelTrainer, train_model
from .evaluate import ModelEvaluator, evaluate_model
from .optimization import BudgetOptimizer, optimize_budget
from .utils import set_seeds, create_project_structure, save_experiment_config

__all__ = [
    'config',
    'DataPreprocessor',
    'preprocess_and_split',
    'MarketingSECNNModel',
    'create_model',
    'ModelTrainer',
    'train_model',
    'ModelEvaluator',
    'evaluate_model',
    'BudgetOptimizer',
    'optimize_budget',
    'set_seeds',
    'create_project_structure',
    'save_experiment_config'
]

